#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rexlib::rexlib" for configuration "Release"
set_property(TARGET rexlib::rexlib APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(rexlib::rexlib PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib64/librexlib.so.0.1.0"
  IMPORTED_SONAME_RELEASE "librexlib.so.0.1.0"
  )

list(APPEND _cmake_import_check_targets rexlib::rexlib )
list(APPEND _cmake_import_check_files_for_rexlib::rexlib "${_IMPORT_PREFIX}/lib64/librexlib.so.0.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
