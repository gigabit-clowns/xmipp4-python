// SPDX-License-Identifier: GPL-3.0-only

#include "version.hpp"

namespace rexlib 
{

REXLIB_INLINE_CONSTEXPR 
version::version(
	std::uint32_t major, 
	std::uint32_t minor, 
	std::uint32_t patch
) noexcept
	: m_data(major) // No need to mask, as it will be shifted
{
	// Shift and write fields
	REXLIB_CONST_CONSTEXPR std::uint32_t right_minor_mask = (1 << minor_bits) - 1;
	m_data <<= minor_bits;
	m_data |= minor & right_minor_mask;

	REXLIB_CONST_CONSTEXPR std::uint32_t right_patch_mask = (1 << patch_bits) - 1;
	m_data <<= patch_bits;
	m_data |= patch & right_patch_mask;
}

REXLIB_INLINE_CONSTEXPR 
void version::set_major(std::uint32_t major) noexcept
{
	major <<= major_offset;
	m_data &= ~major_mask;
	m_data |= major;
}

REXLIB_INLINE_CONSTEXPR 
std::uint32_t version::get_major() const noexcept
{
	return m_data >> major_offset;
}

REXLIB_INLINE_CONSTEXPR 
void version::set_minor(std::uint32_t minor) noexcept
{
	minor <<= minor_offset;
	minor &= minor_mask;
	m_data &= ~minor_mask;
	m_data |= minor;
}

REXLIB_INLINE_CONSTEXPR 
std::uint32_t version::get_minor() const noexcept
{
	return (m_data & minor_mask) >> minor_bits;
}

REXLIB_INLINE_CONSTEXPR 
void version::set_patch(std::uint32_t patch) noexcept
{
	patch &= patch_mask;
	m_data &= ~patch_mask;
	m_data |= patch;
}

REXLIB_INLINE_CONSTEXPR 
std::uint32_t version::get_patch() const noexcept
{
	return m_data & patch_mask;
}

REXLIB_INLINE_CONSTEXPR 
std::uint32_t version::get_data() const noexcept
{
	return m_data;
}

} // namespace rexlib
